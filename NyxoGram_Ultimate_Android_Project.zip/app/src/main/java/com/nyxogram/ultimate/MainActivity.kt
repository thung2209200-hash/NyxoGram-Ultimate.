package com.nyxogram.ultimate
import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebChromeClient
import android.webkit.WebViewClient
import android.view.View
import android.view.WindowManager
import android.graphics.Color
class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  window.statusBarColor = Color.rgb(16,17,27)
  window.navigationBarColor = Color.rgb(16,17,27)
  val web = WebView(this)
  web.setBackgroundColor(Color.rgb(16,17,27))
  web.settings.javaScriptEnabled = true
  web.settings.domStorageEnabled = true
  web.settings.allowFileAccess = true
  web.settings.allowContentAccess = true
  web.webViewClient = WebViewClient()
  web.webChromeClient = WebChromeClient()
  web.loadUrl("file:///android_asset/www/index.html")
  setContentView(web)
 }
}
