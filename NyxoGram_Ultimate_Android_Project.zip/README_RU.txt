NYXOGRAM ULTIMATE — Android offline prototype

WHAT'S INCLUDED
- Android Studio project that wraps the local app in an APK.
- Gifts and demo NFT collectible cards.
- Owner admin panel (initial local PIN 2468).
- Create/delete/rename collectible gifts.
- Create virtual collection numbers.
- Toggle unlimited virtual Premium.
- Add virtual NX balance.
- Local storage and JSON backup import/export.
- No backend/server and no network calls from the app.

IMPORTANT LIMITATIONS
This is an offline personal demo, not Telegram and not an official Telegram Mini App.
"NFT", Premium and numbers are simulated items inside this app. No blockchain, Telegram account, real phone number, payment, or actual Telegram Premium is created.
Without a backend, app data stays on one device/app installation. Local PIN is not strong security. Export backups regularly.
The project is not compiled into an APK in this workspace because Android SDK/Gradle build tools are not installed here.

HOW TO GET THE APK FROM A PHONE
1. Create a GitHub repository and upload all files/folders from this ZIP.
2. Open the repository → Actions → "Build NyxoGram APK" → Run workflow.
3. When the run finishes, open it and download the artifact "NyxoGram-debug-APK".
4. Extract the artifact ZIP and install app-debug.apk on your Android phone. Android may ask permission to install apps from that source.

For editing the project, open it in Android Studio on a computer. GitHub Actions builds the APK in the cloud; that is only a build service, not an app backend.
