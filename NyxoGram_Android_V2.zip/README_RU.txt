NYXOGRAM V2 — Android demo project

This is an offline local demo. Gifts, collectible cards, Premium, NX and IDs
are virtual app data only. They are not real Telegram products, NFTs,
telephone numbers, cryptocurrency or payment services. No server or real
payments are used. Data stays on this device. Demo admin PIN: 2468.

GITHUB BUILD:
1. Create/open an empty GitHub repository.
2. Extract this ZIP.
3. Upload the CONTENTS of this folder to the ROOT of the repository.
   Root must contain settings.gradle, build.gradle, app/ and .github/.
   Do not upload this ZIP file into the repository.
4. Open Actions. Select "Build NyxoGram APK" and run workflow if needed.
5. Open the successful run and download artifact "NyxoGram-debug-apk".
6. Extract that artifact ZIP and install app-debug.apk on Android.

If the build fails, open Actions > failed run > failed step and copy the
plain-text error log. Do not keep replacing project files blindly.

Build configuration: JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3.
